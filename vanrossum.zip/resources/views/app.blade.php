@include('layouts.app')
@include('layouts.navbar')
@yield('content')
@include('layouts.footer')
