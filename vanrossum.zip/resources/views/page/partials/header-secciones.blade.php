<div class="col s12">
	<div id="header-secciones">
		<span >{{ mb_strtoupper($seccion) }}</span>
	</div>
</div>