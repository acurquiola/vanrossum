<?php echo $__env->make('adm.datos.redes.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Editar</a>
				</div>

				<h5>Información de Redes Sociales</h5>					
				<div class="divider"></div>
				<table class="index-table responsive-table ">
					<tbody>
						<?php if($ig): ?>
							<tr>
								<td><b>Instagram</b></td>
								<td><?php echo e($ig->descripcion); ?></td>
								<td >
									<a href=" <?php echo e(action('DatoController@editRedes', $ig->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
						<?php if($fb): ?>
							<tr>
								<td><b>Facebook</b></td>
								<td><?php echo e($fb->descripcion); ?></td>
								<td >
									<a href=" <?php echo e(action('DatoController@editRedes', $fb->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>