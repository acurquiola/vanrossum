<?php $__env->startSection('content'); ?>


	<body>
		<div class="container">
			<div class="row">
				<ul class="collapsible z-depth-0"  style="border: 0 !important">
				<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<div class="collapsible-header header-categorias" ><?php echo e(mb_strtoupper($c->nombre)); ?></div>
						<?php $__empty_1 = true; $__currentLoopData = $c->preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<div class="collapsible-body valign-wrapper header-preguntas">
								<span><?php echo e(mb_strtoupper($p->pregunta)); ?></span>
								<p><?php echo e($p->respuesta); ?></p>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<div class="collapsible-body valign-wrapper">
								<span>No disponemos preguntas para esta categoría</span>
							</div>
						<?php endif; ?>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>	
		</div>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>