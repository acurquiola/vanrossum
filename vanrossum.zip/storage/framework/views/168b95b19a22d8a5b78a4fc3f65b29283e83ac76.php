<?php echo $__env->make('adm.productos.presentaciones.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<a class="breadcrumb">Editar</a>
</div>

<h5>Presentación</h5>					
<div class="divider"></div>
<div class="col s12">

	<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('PresentacionController@update', $presentacion->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
		<?php echo e(csrf_field()); ?>    
		<?php echo e(method_field('PUT')); ?>  

		<div class="row">
			<h5>Editar</h5>					
			<div class="divider"></div>

			<div class="input-field col s4">
				<i class="material-icons prefix">keyboard_arrow_right</i>
				<input id="icon_prefix" type="text" class="validate" name="cantidad" value="<?php echo e($presentacion->cantidad); ?>">
				<label for="icon_prefix">Cantidad</label>
			</div>
			<div class="input-field col s4">
				<select class="materialSelect" id="unidad" name="unidad_id">
					<?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($u->id); ?>" <?php if($u->id == $presentacion->unidad_id): ?> selected <?php endif; ?>  ><?php echo e(ucwords($u->abreviacion)); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>

			<div class="input-field col s4">
				<i class="material-icons prefix">keyboard_arrow_right</i>
				<input id="icon_prefix" type="text" class="validate" name="precio" value="<?php echo e($presentacion->precio); ?>">
				<label for="icon_prefix">Precio (USD)</label>
			</div>



			<div class="right">
				<a href="<?php echo e(action('PresentacionController@index', $producto->id)); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
				<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
					<i class="material-icons right">send</i>
				</button>
			</div>
		</div>
	</form>

</div>
</div>
</div>
</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  
	});
</script>


</body>

</html>