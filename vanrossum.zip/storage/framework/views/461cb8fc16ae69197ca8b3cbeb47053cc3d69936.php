<?php echo $__env->make('adm.datos.contacto.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Editar</a>
				</div>

				<h5>Información de Contacto</h5>					
				<div class="divider"></div>
				<table class="index-table responsive-table ">
					<tbody>
						<?php if($direccion): ?>
							<tr>
								<td><b>Dirección</b></td>
								<td><?php echo e($direccion->descripcion); ?></td>
								<td >
									<a href=" <?php echo e(action('DatoController@editContacto', $direccion->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
						<?php if($email): ?>
							<tr>
								<td><b>Correo Electrónico</b></td>
								<td><?php echo e($email->descripcion); ?></td>
								<td >
									<a href=" <?php echo e(action('DatoController@editContacto', $email->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
						<?php if($telefono): ?>
							<tr>
								<td><b>N° de Teléfono</b></td>
								<td><?php echo e($telefono->descripcion); ?></td>
								<td >
									<a href=" <?php echo e(action('DatoController@editContacto', $telefono->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
						<?php if($mapa): ?>
							<tr>
								<td><b>Link Mapa</b></td>
								<td><?php echo e(substr($mapa->descripcion, 0, 70)); ?>...</td>
								<td >
									<a href=" <?php echo e(action('DatoController@editContacto', $mapa->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange right"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>