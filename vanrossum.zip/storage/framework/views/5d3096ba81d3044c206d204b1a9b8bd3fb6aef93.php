<?php $__env->startSection('content'); ?>


<body>


	<div class="container" style="width: 85%">

		<?php echo $__env->make('page.partials.header-secciones', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="row" id="familias-row">
			
			<?php echo $__env->make('page.productos.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php if($items->count() > 0 || $productos->count() > 0): ?>
				<div class="col s12 m12 l9 center">
					<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col s12 m12 l4">
							<div class="familia-productos center">
						        <div class="efecto">
									<a href="<?php echo e(action('SeccionProductoController@listar', ['id' => $i->id, 'padre' => $familia_padre->id])); ?>">
										<img src="<?php echo e(asset('images/familias/hover-familias.png')); ?>" class="responsive-img" style="width: 100%">
									</a>  
								</div>
								<img class="familia-img" src="<?php echo e(asset('images/familias/'.$i->file_image)); ?>">
							</div>
							<p class="producto-nombre"><?php echo e($i->nombre); ?></p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
					<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col s12 m12 l4">
							<div class="familia-productos">
						        <div class="efecto">
									<a href="<?php echo e(action('SeccionProductoController@show', ['id' => $i->id, 'padre' => $familia_padre->id])); ?>">
										<img src="<?php echo e(asset('images/familias/hover-familias.png')); ?>" class="responsive-img" style="width: 100%">
									</a>  
								</div>
								<img class="familia-img" src="<?php echo e(asset('images/productos/'.$i->file_image)); ?>">
							</div>
							<p class="producto-nombre"><?php echo e($i->nombre); ?></p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>	
		
			<?php if($productos->count() == 0 && $items->count() == 0): ?>
				<div class="col s12 m12 l9 center">
					<h5>No conseguimos registros para esta selección</h5>
				</div>	
			<?php endif; ?>
		</div>
	</div>

	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>