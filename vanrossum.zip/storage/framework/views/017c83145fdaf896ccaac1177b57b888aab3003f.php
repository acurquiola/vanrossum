<div class="col s12">
	<div id="header-secciones">
		<span ><?php echo e(mb_strtoupper($seccion)); ?></span>
	</div>
</div>