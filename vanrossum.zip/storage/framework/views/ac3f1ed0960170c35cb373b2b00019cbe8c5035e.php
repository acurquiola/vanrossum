
<div class="slider" id="slider-home">
	<ul class="slides">
		<?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<li>
			<img src="<?php echo e(asset('images/sliders/'.$s->file_image)); ?>" class="responsive-img"> 
			<?php if($s->seccion == 'home'): ?>
				<div class="caption center-align  hide-on-med-and-down" id="slider-caption">  
					<div id="titulo-caption">
						<p  id="titulo-caption"><?php echo $s->titulo; ?></p>
					</div>
					<div id="descripcion-caption">
						<p id="descripcion-caption"><?php echo $s->descripcion; ?></p>				
					</div>
				</div>
			<?php endif; ?>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>
	</ul>
</div>


 