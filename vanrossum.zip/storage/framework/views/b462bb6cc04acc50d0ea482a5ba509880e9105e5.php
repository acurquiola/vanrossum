<?php echo $__env->make('adm.logos.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<h5>Logos</h5>					
				<div class="divider"></div>
				<table class="index-table-logos responsive-table ">
					<thead>
						<tr>
							<th>Logo</th>
							<th>Ubicación</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td style="width: 350px"><img src="<?php echo e(asset('images/logos/'.$l->file_image)); ?>"></td>
								 <?php switch($l->ubicacion):
									case ('navbar'): ?>
										<td>Barra Principal</td>  
									<?php break; ?> 
									<?php case ('footer'): ?>
										<td>Pie de Página</td> 
									<?php break; ?>  
									<?php default: ?> 
										<td>Favicon</td> 										
								<?php endswitch; ?>
								<td>
									<a href=" <?php echo e(action('LogoController@edit', $l->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="3">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});

</script>
</body>
</html>