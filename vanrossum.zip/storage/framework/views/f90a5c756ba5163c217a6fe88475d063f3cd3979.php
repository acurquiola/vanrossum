<?php echo $__env->make('adm.novedades.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Crear</a>
				</div>

				<h5>Novedades</h5>					
				<div class="divider"></div>
				<div class="col s12">

					<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('NovedadController@store')); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
						<?php echo e(csrf_field()); ?>    

						<div class="row">
							<h5>Crear</h5>					
							<div class="divider"></div>



							<div class="file-field input-field s12">
								<div class="btn">
									<span>Imagen</span>
									<input type="file" name="file_image">            

								</div>
								<div class="file-path-wrapper">
									<input class="file-path validate" type="text">
									<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 682x405</span>
								</div>
							</div>

							<div class="input-field col s10">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="titulo" >
								<label for="icon_prefix">Título</label>
							</div>

							<div class="input-field col s2">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="orden" >
								<label for="icon_prefix">Orden</label>
							</div>
							<div class="col s12">
								<h6 for="textarea1">Texto</h6>
							</div>
							<div class="input-field col s12">

								<textarea id="texto" name="texto"> </textarea>
							</div>

							<div class="input-field col s6">
								<select name="clasificacion_id">
									<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($c->id); ?>"  ><?php echo e(ucwords($c->nombre)); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="row">
								

								<div class="right">
									<a href="<?php echo e(action('NovedadController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
									<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
										<i class="material-icons right">send</i>
									</button>
								</div>
							</div>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>

	CKEDITOR.replace('texto');
	CKEDITOR.config.height = '150px';
	CKEDITOR.config.width = '100%';

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  
	});
</script>


</body>

</html>