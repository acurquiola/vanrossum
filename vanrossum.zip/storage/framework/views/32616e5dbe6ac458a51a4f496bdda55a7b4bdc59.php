<?php echo $__env->make('adm.productos.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Productos</h5>					
				<div class="divider"></div>
				<table class="index-table-logos responsive-table ">
					<thead>
						<tr>
							<th>Imagen</th>
							<th>Nombre</th>
							<th>Familia</th>
							<th>Orden</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td style="width: 150px;"><img src="<?php echo e(asset('images/productos/'.$p->file_image)); ?>"></td>
								<td ><?php echo e($p->nombre); ?></td>
								<td><?php echo e($p->familia->nombre); ?></td>
								<td><?php echo e($p->orden); ?></td>
								<td>
									<a href=" <?php echo e(action('DescuentoController@index', $p->id)); ?>" class="btn-floating btn waves-effect waves-light blue"><i style="font-size: 15px" class="fas fa-percent"></i></a>
									<a href=" <?php echo e(action('PresentacionController@index', $p->id)); ?>" class="btn-floating btn waves-effect waves-light green"><i style="font-size: 15px" class="fas fa-flask"></i></a>
									<a href=" <?php echo e(action('ProductoController@edit', $p->id)); ?>" class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-pencil-alt"></i></a>
									<a href=" <?php echo e(action('GaleriaController@index', $p->id)); ?>" class="btn-floating btn waves-effect waves-light pink"><i style="font-size: 15px" class="fas fa-images"></i></a>
									<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('ProductoController@eliminar', $p->id)); ?> " class="btn-floating btn waves-effect waves-light deep-orange"><i style="font-size: 15px" class="fas fa-trash-alt"></i></a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="4">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>