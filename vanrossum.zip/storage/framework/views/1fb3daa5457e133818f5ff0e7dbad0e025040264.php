<?php echo $__env->make('adm.logos.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Editar</a>
				</div>
				<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('LogoController@update', $logo->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
					<?php echo e(csrf_field()); ?>    
					<?php echo e(method_field('PUT')); ?>  

					<div class="row">
						<h5>Editar Logo</h5>					
						<div class="divider"></div>
						<div class="file-field input-field s12">
							<div class="btn">
								<span>Imagen</span>
								<input type="file" name="file_image">            

							</div>
							<div class="file-path-wrapper">
								<input class="file-path validate" type="text">
								<?php switch($logo->ubicacion):
									case ('navbar'): ?>
										<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 134x137</span>
									<?php break; ?>
									<?php case ('footer'): ?>
										<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 134x137</span>
									<?php break; ?>
									<?php default: ?>
										<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 32x32</span>
								<?php endswitch; ?>
							</div>
						</div>

						<div class="input-field col s12">
							<select name="seccion" disabled>
								<?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($i); ?>" <?php if($i == $logo->ubicacion): ?> selected <?php endif; ?> ><?php echo e(ucwords($s)); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>

					<div class="right">
						<a href="<?php echo e(action('LogoController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
						<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
							<i class="material-icons right">send</i>
						</button>
					</div>
				</div>
			</form>
		</div>
	</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script>
		$(document).ready(function(){		
			M.AutoInit();
			$('.collapsible').collapsible();
			$('select').formSelect();  


		});
	</script>

</body>
</html>