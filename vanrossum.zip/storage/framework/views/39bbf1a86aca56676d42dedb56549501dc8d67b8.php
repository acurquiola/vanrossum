<?php $__env->startSection('content'); ?>


<body>
	


	<!-- Mapa  -->



		<?php echo $mapa->descripcion; ?>




	<!-- Formulario  -->



		<?php echo $__env->make('page.contacto.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>