
	<div class="col s12 m12 l3">			
		<ul class="collapsible z-depth-0" id="productos-collapsible" data-collapsible="accordion">
				<li class="collapsible-header valign-wrapper" id="productos-collapsible-header" style="border-top: 2px solid #F8A900 !important">
					CATEGORIAS
				</li>
			<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="collapsible-header valign-wrapper <?php echo e(($familia_padre->id == $f->id)?'familia-active':''); ?> " 
						 style="display: flex;
						 		justify-content: space-between; 
						 		align-items: center;" 
						 id="productos-collapsible-header">
						<a href="<?php echo e(action('SeccionProductoController@listar', ['id' => $f->id, 'padre' => $f->id])); ?>" 
						   style="color: #454545"><?php echo e($f->nombre); ?>

						</a>  
						<?php if($familia_padre->id == $f->id): ?> 
							<i class="material-icons right valign-wrapper icon-active">keyboard_arrow_down</i> 
						<?php else: ?>  
							<i class="material-icons right valign-wrapper">keyboard_arrow_right</i>   
						<?php endif; ?>
					</div>
					<?php $__empty_1 = true; $__currentLoopData = $f->subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="collapsible-body valign-wrapper <?php echo e(($familia_padre->id == $s->id)?'familia-active':''); ?>" 
							 id="productos-collapsible-body" 
							 <?php if($familia_padre->id == $s->familia_id): ?> 
							 	style="display:block;" 
							 <?php endif; ?>>
							<a href="<?php echo e(action('SeccionProductoController@listar', ['id' => $s->id, 'padre' => $s->familia_id])); ?>"><?php echo e(mb_strtoupper($s->nombre)); ?></a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
					<?php $__empty_1 = true; $__currentLoopData = $f->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="collapsible-body valign-wrapper <?php echo e(($familia_padre->id == $p->familia_id)?'familia-active':''); ?>" 
							 id="productos-collapsible-body" 
							 <?php if($familia_padre->id == $p->familia_id): ?> 
							 	style="display:block;" 
							 <?php endif; ?>>
							<a href="<?php echo e(action('SeccionProductoController@show', ['id' => $p->id, 'padre' => $p->familia_id])); ?>"><?php echo e(mb_strtoupper($p->nombre)); ?></a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>


