<?php $__env->startSection('content'); ?>


<body>


<div class="container">
	
	<div class="row">
		
		<div class="col s12 m12 l9">

			<ul class="tabs">
				<li class="tab col s3" style="text-align: left !important"><a href="#" class="active titulo-tab-novedades" ><?php echo e($novedad->clasificacion->nombre); ?></a></li>
			</ul>
			<div class="divider" style="background: #FFC107; height: 4px; margin-bottom: 5%"></div>
            <img src="<?php echo e(asset('images/novedades/'.$novedad->file_image)); ?>" alt="" class="responsive-img">

            <div class="texto">
            	<p id="titulo-show-novedades"><?php echo e($novedad->titulo); ?></p>
            	<span id="descripcion-show-novedades"><?php echo $novedad->texto; ?></span>
            </div>
            <div class="row">
 				<a style=" color: #009BDB " id="link-index-novedades" href=" <?php echo e(url()->previous()); ?>" ><i style=" position: relative; top: 7px;" class="material-icons">arrow_back</i> VOLVER</a>
            </div>
		</div>

		<div class="col s12 m12 l3">
			<p id="titulo-categorias">Categorías</p>
			<div class="divider" style="background: #B0B0B0;"></div>

			<ul class="collection" id="collection-novedades">
				<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      		<a href="<?php echo e(route('filtros', $c->id)); ?>" class="collection-item" id="collection-novedades-item"><i class="fas fa-angle-double-right" style="margin-right: 5%"></i><?php echo e($c->nombre); ?></a>
		      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </ul>
		</div>
	</div>
		
</div>
	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>