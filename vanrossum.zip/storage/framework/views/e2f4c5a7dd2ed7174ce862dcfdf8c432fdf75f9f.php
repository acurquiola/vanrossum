<li>
	<div class="collapsible-header valign-wrapper" 
		 style=" display: flex;justify-content: space-between; align-items: center;" 
		 id="productos-collapsible-header">
		<a href="#"
		   style="color: #454545">
		   <?php echo e($f->nombre); ?>

		</a>  
			<i class="material-icons right valign-wrapper">keyboard_arrow_down</i> 
	</div>
</li>
	<?php if($f->subfamilias->count() > 0): ?>
		<ul class="collapsible z-depth-0" id="productos-collapsible" data-collapsible="accordion">
			<?php $__currentLoopData = $f->subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('page.productos.partials.submenu', $f, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>