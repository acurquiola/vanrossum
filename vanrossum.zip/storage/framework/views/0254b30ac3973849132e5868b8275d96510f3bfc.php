
Has recibido un pedido de : <?php echo e($usuario->name); ?>


<p>
Pedido nro: <?php echo e($compra->id); ?>

</p>

Medio de Pago: <?php echo e($compra->medio_pago); ?>


<table class="center">
<thead>
  <tr>
      <th>Descripción</th>
      <th>Cantidad</th>
      <th>Monto</th>
  </tr>
</thead>

<tbody>
	<?php $__currentLoopData = $compra->presentaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	  <tr>
	    <td><?php echo e($a->producto->nombre); ?></td>
	    <td><?php echo e($a->pivot->cantidad); ?></td>
	    <td><?php echo e($a->precio); ?></td>
	  </tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<tfoot>
	<tr>
		<td colspan="2">Total</td>
		<td><?php echo e($compra->monto); ?></td>
	</tr>
</tfoot>
</table>
