<div class="container" id="container-fluid" style="margin-top: 5%">

	<div class="row">
		<div class="col s12">			
			<?php if($errors->any()): ?>
			<div class="card-panel alert-error">
				<ul><li>ALERTA:
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <?php echo e($error); ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</li>
				</ul>
			</div>
			<?php endif; ?>

			<?php if(session('alert')): ?>
			<div class="card-panel alert-success">
				<ul><li>ALERTA:
						<?php echo e(session('alert')); ?>				
					</li>
				</ul>
			</div>
			<?php endif; ?>
		</div>
		<div class="col s12 m3">
			<ul class="contacto-info" >
				<li class="contacto-text">
					<div class="row">
						<div class="col s1 contacto-icon">
							<i class="fas fa-map-marker-alt"></i>
						</div>
						<div class="col s10">
							<a target="_blank" href="https://goo.gl/maps/Fg7NECFuJgu"><?php echo e($direccion->descripcion); ?></a>
						</div>
					</div>
				</li>
				<li class="contacto-text">
					<div class="row">
						<div class="col s1 contacto-icon">
							<i class="fas fa-phone"></i>
						</div>
						<div class="col s10">
							<a href="tel:<?php echo e($telefono->descripcion); ?>"><?php echo e($telefono->descripcion); ?></a>
						</div>
					</div>
				</li>
				<li class="contacto-text">
					<div class="row">
						<div class="col s1 contacto-icon">
							<i class="fas fa-envelope"></i>
						</div>
						<div class="col s10">
							<a href="mailto:<?php echo e($email->descripcion); ?>"><?php echo e($email->descripcion); ?></a> 
						</div>
					</div>
				</li>
			</ul>
		</div>
		<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('SeccionContactoController@store')); ?>" class="col s12 l9 ">
			<?php echo e(csrf_field()); ?>


			<div class="row">
				<div class="input-field col s12 m6 l6">
					<input id="icon_prefix" type="text" class="validate" name="nombre"  value="<?php echo e(old('nombre')); ?>">
					<label class="label-form-contact" for="icon_prefix">Nombre</label>
				</div>
				<div class="input-field col s12 m6 l6">
					<input id="icon_prefix" type="text" class="validate" name="apellido"  value="<?php echo e(old('apellido')); ?>">
					<label class="label-form-contact" for="icon_prefix">Apellido</label>
				</div>
			</div>
			<div class="row">
				<div class="input-field col s12 m6 l6">
					<input id="email" type="email"  name="email" class="validate"  value="<?php echo e(old('email')); ?>">
					<label class="label-form-contact" for="email">Email</label>
				</div>
				<div class="input-field col s12 m6 l6">
					<input  id="empresa" type="text" name="empresa" class="validate"  value="<?php echo e(old('empresa')); ?>">
					<label class="label-form-contact" for="empresa">Empresa</label>
				</div>
			</div>
			<div class="row">
				<div class="input-field col s12 m6 l6">
					<input id="mensaje" type="text" name="mensaje" class="validate"  <?php if($mensaje!=''): ?> value="<?php echo e($mensaje); ?>" <?php else: ?> value="<?php echo e(old('mensaje')); ?>" <?php endif; ?>>
					<label class="label-form-contact" for="mensaje">Mensaje</label>
				</div>
				<div class="input-field col s12 m6 l6">
					<div class="g-recaptcha" data-sitekey = "<?php echo e(env('GOOGLE_RECAPTCHA_SITE_KEY')); ?>"></div>
				</div> 
			</div>
			<div class="center">
				<button class="btn button-enviar-mas z-depth-0 center" type="submit" style="background-color: #F8A900; width: 132px; color: #FFFFFF;" name="action">Enviar</button>
			</div>
		</form>
	</div>
</div>

