<?php $__env->startSection('title', 'login here'); ?>


<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <main>
            <center>
                <div class="container" >
                    <div  class="z-depth-3 y-depth-3 x-depth-3 grey lighten-4 row" style="background: #FFFFFF !important; display: inline-block; padding: 32px 48px 0px 48px; border: 1px; margin-top: 100px; solid #EEE; width: 470px ; border-radius: 5px;">
                        <div class="section">
                            <img src='<?php echo e(asset("images/logos/".$logos->file_image)); ?>' alt="">
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('admin.auth.loginAdmin')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <div class="row">

                                    <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                        <label for="username" class="col m12 control-label">Username</label>

                                        <div class="col m12">
                                            <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                                            <?php if($errors->has('username')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('username')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                        <label for="password" class="col m12 control-label">Password</label>

                                        <div class="col m12">
                                            <input id="password" type="password" class="form-control" name="password" required>

                                            <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="center">
                                        <div class="col m12">
                                            <button type="submit" class="btn btn-primary" id="btn_login">
                                                INGRESAR
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </center>
            </main>
        </div>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>