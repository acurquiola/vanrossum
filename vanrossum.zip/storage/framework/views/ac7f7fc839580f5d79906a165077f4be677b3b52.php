<?php echo $__env->make('adm.cuentas.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Cuentas</h5>					
				<div class="divider"></div>
				<table class="index-table responsive-table ">
					<thead>
						<tr>
							<th>Descripción</th>
							<th>Opciones</th>

						</tr>
					</thead>
					<tbody>
						<?php if($cuentas->count()>0): ?>
							<?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($c->descripcion); ?></td>
								<td><a href=" <?php echo e(action('CuentaController@edit', $c->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<tr>
							<td colspan="4">No existen registros</td>
						</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>