<?php $__env->startSection('content'); ?>


<body>

	<?php if(Session::get('medio_pago')  == 'mercado_pago' ): ?>
		<div class="container" style="padding: 50px;">
			<div class="center">		
				<span>Orden generada exitósamente.</span>

				<div class="col s12 l6" >
					<a id="estandar-btn"  href=<?php echo e(Session::get('confirmacion_url')); ?> class="btn center-align">PROCESAR PAGO</a>	
					
				</div>
			</div>
		</div>
	<?php else: ?>
		<div class="container" style="padding: 50px;">
			<div class="center">		
				<span>Orden registrada exitósamente.</span>

				<div class="col s12 l6" >
					<a id="estandar-btn" href="<?php echo e(action('SeccionProductoController@index')); ?>" class="btn center-align">VOLVER</a>	
				</div>
			</div>
		</div>

	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
	$(document).ready(function(){  
		$('#slider-home').slider({
			height: 479,
		})
	});

</script>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>