<?php echo $__env->make('adm.productos.familias.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>
				<div class="row">
					<div class="col s12">
						<?php if($nivel <= '1'): ?>
						<div class="col s12">
							<h5>Familias</h5>	
						</div>
						<?php else: ?>
						<div class="col s6">
							<h5>Subcategorías de <?php echo e($familia_padre->nombre); ?></h5>	
						</div>
						<div class="col s6">
							<div class="right">
								<a href="<?php echo e(action('SubfamiliaController@create', $familia_padre->id)); ?>" class="waves-effect waves-light btn"><i class="material-icons left">cloud</i>Agregar Subcategoría</a>
							</div>
						</div>
						<?php endif; ?>	
					</div>
				</div>
				<div class="divider"></div>
				<table class="index-table-logos responsive-table ">
					<thead>
						<tr>
							<th>Imagen</th>
							<th>Nombre</th>
							<th>Orden</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td style="width: 350px;"><img src="<?php echo e(asset('images/familias/'.$f->file_image)); ?>"></td>
								<td ><?php echo e($f->nombre); ?></td>
								<td><?php echo e($f->orden); ?></td>
								<td>
									<a href=" <?php echo e(action('SubfamiliaController@index', $f->id)); ?> " class="btn-floating btn-large waves-effect waves-light green"><i class="fas fa-folder-plus"></i></a>
									<a href=" <?php echo e(action('FamiliaController@edit', $f->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
									<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('FamiliaController@eliminar', $f->id)); ?> " class="btn-floating btn-large waves-effect waves-light deep-orange"><i class="fas fa-trash-alt"></i></a>

								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="4">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>