<?php $__env->startSection('content'); ?>


<body>


	<?php echo $__env->make('page.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="container">
		<div class="row">
			<div class="col s12  m12 l4">
				<img src="<?php echo e(asset('images/empresa/'.$empresa->file_image)); ?>" class="responsive-img">
			</div>
			<div class="col s12  m12 l8 " id="descripcion-empresa">
				<div class="card card-empresa z-depth-0">
					<div class="card-content">
						<span class="card-title title-empresa">MISIÓN</span>
						<p class="content-empresa"><?php echo e($empresa->mision); ?></p>
					</div>
				</div>
				<div class="card card-empresa z-depth-0">
					<div class="card-content">
						<span class="card-title title-empresa">VISIÓN</span>
						<p class="content-empresa"><?php echo e($empresa->vision); ?></p>
					</div>
				</div>
				<div class="card card-empresa z-depth-0">
					<div class="card-content">
						<span class="card-title title-empresa">VALORES</span>
						<p class="content-empresa"><?php echo e($empresa->valores); ?></p>
					</div>
				</div>
			</div>
		</div>

	</div>


	
	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script>
		$(document).ready(function(){  
			$('#slider-home').slider({
				height: 479,
			})
		});

	</script>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>