<footer class="page-footer" id="footer" style="position: relative;">
		<div class="row" style="margin:0;">
			<div class="col s12 m12 l3" style="padding: 5% 10%" >
				<a href="<?php echo e(url('/')); ?>" class="brand-logo">
					<img id="logo-footer" class="img-responsive" src="<?php echo e(asset("images/logos/".$logos->file_image)); ?>" alt="">
				</a>
			</div>
			<div class="col s12 m12 l9" style="padding-top: 3%">
				<div class="col s12 m12 l5 footer-text">
					<div class="row">
						<span id="nombre-footer">SECCIONES</span>
					</div>
					<div class="row">
						<div class="col s12 m6">
							<a href=" <?php echo e(url('/')); ?> " >Inicio</a>
						</div>
						<div class="col s12 m6">
							<a href=" <?php echo e(url('/novedades')); ?> " >Novedades</a>
						</div>
					</div>
					<div class="row">
						<div class="col s12 m6">
						<a href=" <?php echo e(url('/productos')); ?> " >Productos</a>
						</div>
						<div class="col s12 m6">
							<a href=" <?php echo e(url('/novedades')); ?> " >Quiénes Somos</a>
						</div>
					</div>
					<div class="row">
						<div class="col s12 m6">
						<a href=" <?php echo e(url('/productos')); ?> " >Carrito</a>
						</div>
						<div class="col s12 m6">
							<a href=" <?php echo e(url('/novedades')); ?> " >Contacto</a>
						</div>
					</div>
					<div class="row">
						<div class="col s12 m6">
						<a href=" <?php echo e(url('/productos')); ?> " >Novedades</a>
						</div>
						<div class="col s12 m6">
							<a href=" <?php echo e(url('/preguntas')); ?> " >Cómo Comprar</a>
						</div>
					</div>
				</div>
				
				<div class="col s12 m12 l2 footer-title center">
					<span id="nombre-footer">SEGUINOS</span>
					<div class="row footer-icon-rrss" >
						<a target="_blank" href="<?php echo e($facebook->descripcion); ?>" ><i class="fab fa-facebook"></i></a>
						<a target="_blank" href="<?php echo e($instagram->descripcion); ?>"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
				<div class="col s12 m12 l4 offset-l1 ooter-title">
					<span id="nombre-footer">VAN ROSSUM DISTRIBUIDORA</span>
					<ul style="margin-top: 2%; ">
						<li class="footer-text">
							<div class="row">
								<div class="col s1 footer-icon">
									<i class="fas fa-map-marker-alt"></i>
								</div>
								<div class="col s10">
									<a target="_blank" href="https://goo.gl/maps/Fg7NECFuJgu"><?php echo e($direccion->descripcion); ?></a>
								</div>
							</div>
						</li>
						<li class="footer-text" >
							<div class="row">
								<div class="col s1 footer-icon">
									<i class="fas fa-phone"></i>
								</div>
								<div class="col s10">
									<a href="tel:<?php echo e($telefono->descripcion); ?>"><?php echo e($telefono->descripcion); ?></a>
								</div>
							</div>
						</li>
						<li class="footer-text" style="margin-bottom: 10px">
							<div class="row">
								<div class="col s1 footer-icon">
									<i class="fas fa-envelope"></i>
								</div>
								<div class="col s10">
									<a href="mailto:<?php echo e($email->descripcion); ?>"><?php echo e($email->descripcion); ?></a> 
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div> 
		</div>
		<div class="divider" style="width: 90%; margin-left: 6%; background: #A4A4A4; height: 2px;"></div>
		<div class="row" style="margin:0;">
			<div class="col s12" id="osole-span" >
				<span class="right ">BY OSOLE</span>
			</div>
		</div>
</footer>
