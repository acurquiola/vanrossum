
<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>

<script src="https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js"></script>


<script>

	$(document).ready(function(){  
    	$('.collapsible').collapsible();
    	$('.sidenav').sidenav();
		$('.dropdown-trigger').dropdown({
			constrainWidth: false,
			closeOnClick: false,
			hover: true
		});
		$('.dropdown-buscador').dropdown({
			constrainWidth: false,
			closeOnClick: false,
		});


	});

</script>
