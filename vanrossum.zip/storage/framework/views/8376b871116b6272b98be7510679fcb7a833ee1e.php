<?php $__env->startSection('content'); ?>


<body>

	<?php echo $__env->make('page.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




	<?php if($informacion->count() > 0): ?>
		<div class="row informacion-div">
			<p id="informacion-titulo"><?php echo e($textos->home_titulo); ?></p>
			<p id="informacion-subtitulo"><?php echo e($textos->home_subtitulo); ?></p>
			<div class="container" style="margin-top: 3%; margin-right: 15%">
				<div class="row">
					<?php $__currentLoopData = $informacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col s12 m6 l3 center">
							<img src="<?php echo e(asset('images/home/'.$i->file_image)); ?>">
							<p class="nombre-globos"><?php echo e($i->nombre); ?></p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
	$(document).ready(function(){  
		$('#slider-home').slider({
			height: 479,
		})
	});

</script>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>