<?php echo $__env->make('adm.preguntas.categorias.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Editar</a>
				</div>

				<h5>Categorías</h5>					
				<div class="divider"></div>
				<div class="col s12">

					<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('CategoriaController@update', $categoria->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
						<?php echo e(csrf_field()); ?>    
						<?php echo e(method_field('PUT')); ?>  

						<div class="row">
							<h5>Editar</h5>					
							<div class="divider"></div>

							<div class="input-field col s6">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="nombre"  value="<?php echo e($categoria->nombre); ?>" >
								<label for="icon_prefix">Nombre</label>
							</div>

							<div class="input-field col s6">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="orden"   value="<?php echo e($categoria->orden); ?>" >
								<label for="icon_prefix">Orden</label>
							</div>


							<div class="right">
								<div class="col s6">
									<a href="<?php echo e(action('CategoriaController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
								</div>
								<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
									<i class="material-icons right">send</i>
								</button>
							</div>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  
	});
</script>


</body>

</html>